<template>
    <footer class="footer">
    <img src="../assets/ministryofhealth.png" alt="slogan">
    </footer>
</template>
<script>
export default{
    name:'Footer',
}
</script>
<style scoped>
.footer{
    height: 400px;
    background-color: rgb(24, 32, 29);
    margin-top: 100px;
    padding-left: 40%;
    padding-top: 50px;
}
.footer img{ 
    margin-top: 100px;
    margin: auto;
}
</style>