<template>
  <router-view />
</template>

<script>
//import main_header from "./components/header.vue"
//import HoMe from "./components/Home.vue"
//import Departement from "./components/Departement.vue";
//import FooTer from "./components/footer.vue"
export default {
  name: 'App',
  components: {
    //main_header,
    
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  margin:0;
}
</style>
